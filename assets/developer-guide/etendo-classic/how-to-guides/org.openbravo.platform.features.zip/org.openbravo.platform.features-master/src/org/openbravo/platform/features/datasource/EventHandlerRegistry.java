/*
 *************************************************************************
 * The contents of this file are subject to the Openbravo  Public  License
 * Version  1.1  (the  "License"),  being   the  Mozilla   Public  License
 * Version 1.1  with a permitted attribution clause; you may not  use this
 * file except in compliance with the License. You  may  obtain  a copy of
 * the License at http://www.openbravo.com/legal/license.html
 * Software distributed under the License  is  distributed  on  an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific  language  governing  rights  and  limitations
 * under the License.
 * The Original Code is Openbravo ERP.
 * The Initial Developer of the Original Code is Openbravo SLU
 * All portions are Copyright (C) 2019 penbravo SLU
 * All Rights Reserved.
 * Contributor(s):  ______________________________________.
 ************************************************************************
 */
package org.openbravo.platform.features.datasource;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.enterprise.inject.spi.CDI;
import javax.enterprise.inject.spi.ObserverMethod;

import org.openbravo.base.model.Entity;
import org.openbravo.client.kernel.event.EntityDeleteEvent;
import org.openbravo.client.kernel.event.EntityNewEvent;
import org.openbravo.client.kernel.event.EntityPersistenceEvent;
import org.openbravo.client.kernel.event.EntityUpdateEvent;

/**
 * Class that keeps the information of the event handlers registered in the application.
 */
class EventHandlerRegistry {

  private static EventHandlerRegistry instance = new EventHandlerRegistry();

  private List<EventHandler> eventHandlers;

  public static EventHandlerRegistry getInstance() {
    return instance;
  }

  List<EventHandler> getEventHandlers() {
    if (eventHandlers != null) {
      return eventHandlers;
    }
    synchronized (this) {
      eventHandlers = new ArrayList<>();
      Set<ObserverMethod<? super EntityPersistenceEvent>> s = getObservers(new EntityNewEvent());
      s.addAll(getObservers(new EntityUpdateEvent()));
      s.addAll(getObservers(new EntityDeleteEvent()));
      s.stream().forEach(this::register);
      return eventHandlers;
    }
  }

  List<EventHandler> getEventHandlersForEntity(String entity) {
    return getEventHandlers().stream()
        .filter(eh -> eh.getObservedEntityNames().contains(entity))
        .collect(Collectors.toList());
  }

  Set<String> getObservedEntities() {
    Set<String> entities = getEventHandlers().stream()
        .flatMap(eh -> eh.getObservedEntities().stream())
        .map(Entity::getName)
        .collect(Collectors.toSet());
    // Add "Unknown Entity"
    entities.add(EventHandler.UNKNOWN_ENTITY);
    return entities;
  }

  private Set<ObserverMethod<? super EntityPersistenceEvent>> getObservers(
      EntityPersistenceEvent evt) {
    return CDI.current()
        .getBeanManager()
        .resolveObserverMethods(evt)
        .stream()
        .collect(Collectors.toSet());
  }

  private void register(ObserverMethod<?> method) {
    EventHandler eh = new EventHandler(method);
    int idx = eventHandlers.indexOf(eh);
    if (idx != -1) {
      eventHandlers.get(idx).setType(method);
    } else {
      eventHandlers.add(eh);
    }
  }

}
