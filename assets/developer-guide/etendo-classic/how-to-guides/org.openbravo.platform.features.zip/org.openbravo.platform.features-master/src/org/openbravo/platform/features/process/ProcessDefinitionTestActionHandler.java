package org.openbravo.platform.features.process;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.openbravo.client.application.process.BaseProcessActionHandler;
import org.openbravo.client.application.process.ResponseActionsBuilder.MessageType;

public class ProcessDefinitionTestActionHandler extends BaseProcessActionHandler {
  private static final Logger log = LogManager.getLogger();

  @Override
  protected JSONObject doExecute(Map<String, Object> parameters, String content) {
    try {
      JSONObject request = new JSONObject(content);
      JSONObject params = request.getJSONObject("_params");
      String singleSelector = params.getString("singleBP");
      JSONArray multiSelector = params.getJSONArray("multiBP");
      JSONArray selectedOrders = params.getJSONObject("C_Order_ID").getJSONArray("_selection");

      log.info("Selector SingleBP parameter value:{}", singleSelector);
      log.info("Multiselector MultiBP parameter values:{}", multiSelector);
      log.info("C_Order_ID selected values(total:{}):{}", selectedOrders.length(), selectedOrders);

      return getResponseBuilder()
          .showMsgInProcessView(MessageType.SUCCESS, "Process Successfully Executed")
          .retryExecution()
          .build();
    } catch (JSONException e) {
      log.error("Error in process", e);
      return new JSONObject();
    }
  }
}
