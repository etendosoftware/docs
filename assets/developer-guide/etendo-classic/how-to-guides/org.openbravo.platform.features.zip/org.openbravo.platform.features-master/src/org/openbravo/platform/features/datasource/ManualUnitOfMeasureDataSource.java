/*
 *************************************************************************
 * The contents of this file are subject to the Openbravo  Public  License
 * Version  1.1  (the  "License"),  being   the  Mozilla   Public  License
 * Version 1.1  with a permitted attribution clause; you may not  use this
 * file except in compliance with the License. You  may  obtain  a copy of
 * the License at http://www.openbravo.com/legal/license.html
 * Software distributed under the License  is  distributed  on  an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific  language  governing  rights  and  limitations
 * under the License.
 * The Original Code is Openbravo ERP.
 * The Initial Developer of the Original Code is Openbravo SLU
 * All portions are Copyright (C) 2014-2019 Openbravo SLU
 * All Rights Reserved.
 * Contributor(s):  ______________________________________.
 ************************************************************************
 */

package org.openbravo.platform.features.datasource;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.openbravo.base.model.Entity;
import org.openbravo.base.model.ModelProvider;
import org.openbravo.base.provider.OBProvider;
import org.openbravo.base.structure.BaseOBObject;
import org.openbravo.dal.service.OBCriteria;
import org.openbravo.dal.service.OBDal;
import org.openbravo.model.common.uom.UOM;
import org.openbravo.service.datasource.DefaultDataSourceService;
import org.openbravo.service.json.DataToJsonConverter;
import org.openbravo.service.json.JsonConstants;
import org.openbravo.service.json.JsonToDataConverter;

/**
 * Test manual datasource that implements the fetch, add and delete operation for the Unit of
 * Measure table
 */
public class ManualUnitOfMeasureDataSource extends DefaultDataSourceService {

  // Table ID of the datasource based table defined in the application dictionary
  private static final String AD_TABLE_ID = "146";

  @Override
  public Entity getEntity() {
    return ModelProvider.getInstance().getEntityByTableId(AD_TABLE_ID);
  }

  @Override
  public String fetch(Map<String, String> parameters) {
    OBCriteria<UOM> criteria = OBDal.getInstance().createCriteria(UOM.class);
    @SuppressWarnings("unchecked")
    List<BaseOBObject> uomList = (List<BaseOBObject>) (Object) criteria.list();
    final DataToJsonConverter toJsonConverter = OBProvider.getInstance()
        .get(DataToJsonConverter.class);
    final List<JSONObject> jsonObjects = toJsonConverter.toJsonObjects(uomList);

    final JSONObject jsonResult = new JSONObject();
    final JSONObject jsonResponse = new JSONObject();
    try {
      jsonResponse.put(JsonConstants.RESPONSE_STARTROW, 0);
      jsonResponse.put(JsonConstants.RESPONSE_ENDROW, (uomList.size()));
      jsonResponse.put(JsonConstants.RESPONSE_TOTALROWS, (uomList.size()));
      jsonResponse.put(JsonConstants.RESPONSE_DATA, new JSONArray(jsonObjects));
      jsonResponse.put(JsonConstants.RESPONSE_STATUS, JsonConstants.RPCREQUEST_STATUS_SUCCESS);
      jsonResult.put(JsonConstants.RESPONSE_RESPONSE, jsonResponse);
    } catch (JSONException e) {
    }
    return jsonResult.toString();
  }

  @Override
  public String remove(Map<String, String> parameters) {
    final String id = parameters.get(JsonConstants.ID);
    BaseOBObject bob = OBDal.getInstance().get(UOM.class, id);
    final JSONObject jsonResult = new JSONObject();
    if (bob != null) {
      try {
        // create the result info before deleting to prevent Hibernate errors
        final DataToJsonConverter toJsonConverter = OBProvider.getInstance()
            .get(DataToJsonConverter.class);
        final List<JSONObject> jsonObjects = toJsonConverter
            .toJsonObjects(Collections.singletonList(bob));
        final JSONObject jsonResponse = new JSONObject();
        jsonResponse.put(JsonConstants.RESPONSE_STATUS, JsonConstants.RPCREQUEST_STATUS_SUCCESS);
        jsonResponse.put(JsonConstants.RESPONSE_DATA, new JSONArray(jsonObjects));
        jsonResult.put(JsonConstants.RESPONSE_RESPONSE, jsonResponse);
        OBDal.getInstance().remove(bob);
        OBDal.getInstance().commitAndClose();
      } catch (Throwable t) {

      }
    }
    return jsonResult.toString();
  }

  @Override
  public String add(Map<String, String> parameters, String content) {
    final JSONObject jsonResult = new JSONObject();
    try {
      final JsonToDataConverter fromJsonConverter = OBProvider.getInstance()
          .get(JsonToDataConverter.class);
      final JSONObject jsonObject = new JSONObject(content);
      JSONObject data = (JSONObject) jsonObject.get(JsonConstants.DATA);
      data.put(JsonConstants.ENTITYNAME, "UOM");
      data.put(JsonConstants.NEW_INDICATOR, true);
      final List<BaseOBObject> bobs = Collections
          .singletonList(fromJsonConverter.toBaseOBObject((JSONObject) data));
      for (BaseOBObject bob : bobs) {
        OBDal.getInstance().save(bob);
      }
      OBDal.getInstance().flush();
      final DataToJsonConverter toJsonConverter = OBProvider.getInstance()
          .get(DataToJsonConverter.class);
      final List<JSONObject> jsonObjects = toJsonConverter.toJsonObjects(bobs);
      final JSONObject jsonResponse = new JSONObject();
      jsonResponse.put(JsonConstants.RESPONSE_STATUS, JsonConstants.RPCREQUEST_STATUS_SUCCESS);
      jsonResponse.put(JsonConstants.RESPONSE_DATA, new JSONArray(jsonObjects));
      jsonResult.put(JsonConstants.RESPONSE_RESPONSE, jsonResponse);
      OBDal.getInstance().commitAndClose();
    } catch (Exception e) {
      e.printStackTrace();
    }
    return jsonResult.toString();
  }
}
