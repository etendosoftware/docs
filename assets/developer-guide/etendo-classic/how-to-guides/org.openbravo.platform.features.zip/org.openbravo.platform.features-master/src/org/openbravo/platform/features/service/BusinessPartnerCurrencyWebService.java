/*
 *************************************************************************
 * The contents of this file are subject to the Openbravo  Public  License
 * Version  1.1  (the  "License"),  being   the  Mozilla   Public  License
 * Version 1.1  with a permitted attribution clause; you may not  use this
 * file except in compliance with the License. You  may  obtain  a copy of
 * the License at http://www.openbravo.com/legal/license.html 
 * Software distributed under the License  is  distributed  on  an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific  language  governing  rights  and  limitations
 * under the License. 
 * The Original Code is Openbravo ERP. 
 * The Initial Developer of the Original Code is Openbravo SLU 
 * All portions are Copyright (C) 2017 Openbravo SLU 
 * All Rights Reserved. 
 * Contributor(s):  ______________________________________.
 ************************************************************************
 */

package org.openbravo.platform.features.service;

import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.openbravo.authentication.AuthenticationManager;
import org.openbravo.base.structure.BaseOBObject;
import org.openbravo.dal.service.OBDal;
import org.openbravo.dal.service.OBQuery;
import org.openbravo.dal.xml.EntityXMLConverter;
import org.openbravo.model.common.businesspartner.BusinessPartner;
import org.openbravo.model.common.currency.Currency;
import org.openbravo.service.web.WebService;

@AuthenticationManager.Stateless
public class BusinessPartnerCurrencyWebService implements WebService {

  @Override
  public void doGet(String path, HttpServletRequest request, HttpServletResponse response)
      throws Exception {

    // check parameters
    final String currencyID = request.getParameter("currency");
    if (currencyID == null) {
      throw new IllegalArgumentException("The currency parameter is mandatory");
    }
    final Currency currency = OBDal.getInstance().get(Currency.class, currencyID);
    if (currency == null) {
      throw new IllegalArgumentException("Currency with id: " + currencyID + " does not exist");
    }

    // build the result
    String xml = buildResult(getBusinessPartners(currency));

    // write to the response
    response.setContentType("text/xml");
    response.setCharacterEncoding("utf-8");
    final Writer w = response.getWriter();
    w.write(xml);
    w.close();
  }

  private List<BaseOBObject> getBusinessPartners(Currency currency) {
    final OBQuery<BaseOBObject> query = OBDal.getInstance().createQuery(
        BusinessPartner.ENTITY_NAME, "currency.id=:currencyId");
    query.setNamedParameter("currencyId", currency.getId());
    return query.list();
  }

  private String buildResult(List<BaseOBObject> businessPartners) {
    final EntityXMLConverter exc = EntityXMLConverter.newInstance();
    final List<String> propertiesToExport = new ArrayList<>();

    propertiesToExport.add("searchKey");
    propertiesToExport.add("description");
    propertiesToExport.add("language");
    exc.setIncludedProperties(propertiesToExport);

    StringWriter sw = new StringWriter();
    exc.setOutput(sw);
    exc.process(businessPartners);
    return sw.toString();
  }

  @Override
  public void doPost(String path, HttpServletRequest request, HttpServletResponse response)
      throws Exception {
  }

  @Override
  public void doDelete(String path, HttpServletRequest request, HttpServletResponse response)
      throws Exception {
  }

  @Override
  public void doPut(String path, HttpServletRequest request, HttpServletResponse response)
      throws Exception {
  }

}