/*
 *************************************************************************
 * The contents of this file are subject to the Openbravo  Public  License
 * Version  1.0  (the  "License"),  being   the  Mozilla   Public  License
 * Version 1.1  with a permitted attribution clause; you may not  use this
 * file except in compliance with the License. You  may  obtain  a copy of
 * the License at http://www.openbravo.com/legal/license.html
 * Software distributed under the License  is  distributed  on  an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific  language  governing  rights  and  limitations
 * under the License.
 * The Original Code is Openbravo ERP.
 * The Initial Developer of the Original Code is Openbravo SLU
 * All portions are Copyright (C) 2018 Openbravo SLU
 * All Rights Reserved.
 * Contributor(s):  ______________________________________.
 *************************************************************************
 */
package org.openbravo.platform.features.process;

import java.util.Map;

import javax.inject.Inject;

import org.codehaus.jettison.json.JSONObject;
import org.openbravo.client.application.process.BaseProcessActionHandler;
import org.openbravo.client.application.process.ResponseActionsBuilder.MessageType;
import org.openbravo.dal.core.OBContext;
import org.openbravo.email.EmailEventManager;
import org.openbravo.platform.features.email.EmailGenerator;

/**
 * Action handler to test the e-mail events feature. The content of the email will be generated with
 * the {@link EmailGenerator} class.
 */
public class SendEmailActionHandler extends BaseProcessActionHandler {

  @Inject
  private EmailEventManager emailEventManager;

  @Override
  protected JSONObject doExecute(Map<String, Object> parameters, String content) {
    try {
      JSONObject jsonContent = new JSONObject(content);
      JSONObject jsonParams = jsonContent.getJSONObject("_params");
      String email = jsonParams.getString("email");

      boolean sent = emailEventManager.sendEmail("EVT_NAME", email, OBContext.getOBContext()
          .getUser());

      return sent ? getSuccessResponse("Email sent") : getErrorResponse("Email not sent");

    } catch (Exception e) {
      return getErrorResponse(e.getMessage());
    }
  }

  private JSONObject getSuccessResponse(String message) {
    return getResponseBuilder() //
        .showMsgInProcessView(MessageType.SUCCESS, message) //
        .build();
  }

  private JSONObject getErrorResponse(String message) {
    return getResponseBuilder() //
        .showMsgInProcessView(MessageType.ERROR, message) //
        .build();
  }

}
