/*
 ************************************************************************************
 * Copyright (C) 2020 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************
 */
package org.openbravo.platform.features.hqltransformer;

import java.util.Arrays;
import java.util.Map;

import org.openbravo.service.datasource.hql.HQLInserterQualifier;
import org.openbravo.service.datasource.hql.HqlInserter;
import org.apache.commons.lang.StringUtils;
import org.openbravo.service.json.JsonConstants;

@HQLInserterQualifier.Qualifier(tableId = "E2AC7ECFB75F4056A9BEFDD8A30A6C9E", injectionId = "0")
public class SimpleOrderHQLTransformer extends HqlInserter {

  @Override
  public String insertHql(Map<String, String> requestParameters,
      Map<String, Object> queryNamedParameters) {
    String bpId = requestParameters.get("singleBP");
    String bpIds = requestParameters.get("multiBP");
    if (!StringUtils.isEmpty(bpIds)) {
      queryNamedParameters.put("bpIds", Arrays.asList(bpIds.split(JsonConstants.IN_PARAMETER_SEPARATOR)));
      return "e.businessPartner.id in (:bpIds)";
    }
    if (!StringUtils.isEmpty(bpId)) {
      queryNamedParameters.put("bpId", bpId);
      return "e.businessPartner.id = :bpId";
    }
    return "1=1";
  }
}
