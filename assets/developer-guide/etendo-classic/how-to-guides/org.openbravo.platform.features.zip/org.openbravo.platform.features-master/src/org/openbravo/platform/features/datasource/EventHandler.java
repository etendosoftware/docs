/*
 *************************************************************************
 * The contents of this file are subject to the Openbravo  Public  License
 * Version  1.1  (the  "License"),  being   the  Mozilla   Public  License
 * Version 1.1  with a permitted attribution clause; you may not  use this
 * file except in compliance with the License. You  may  obtain  a copy of
 * the License at http://www.openbravo.com/legal/license.html
 * Software distributed under the License  is  distributed  on  an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
 * License for the specific  language  governing  rights  and  limitations
 * under the License.
 * The Original Code is Openbravo ERP.
 * The Initial Developer of the Original Code is Openbravo SLU
 * All portions are Copyright (C) 2019 penbravo SLU
 * All Rights Reserved.
 * Contributor(s):  ______________________________________.
 ************************************************************************
 */
package org.openbravo.platform.features.datasource;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.enterprise.inject.spi.ObserverMethod;

import org.openbravo.base.model.Entity;

/**
 * Represents an event handler. Contains the required information by the
 * {@link EventHandlerDataSource} class.
 */
class EventHandler {
  static final String UNKNOWN_ENTITY = "Unknown";
  private static final Set<String> UNKNOWN = new HashSet<>(Arrays.asList(UNKNOWN_ENTITY));
  private static final String ON_NEW = "org.openbravo.client.kernel.event.EntityNewEvent";
  private static final String ON_UPDATE = "org.openbravo.client.kernel.event.EntityUpdateEvent";
  private static final String ON_DELETE = "org.openbravo.client.kernel.event.EntityDeleteEvent";
  private static final String ALL = "org.openbravo.client.kernel.event.EntityPersistenceEvent";

  private Class<?> clazz;
  private boolean onNew;
  private boolean onUpdate;
  private boolean onDelete;
  private List<Entity> observedEntities;

  EventHandler(ObserverMethod<?> method) {
    this.clazz = method.getBeanClass();
    setType(method);
  }

  void setType(ObserverMethod<?> method) {
    String typeName = method.getObservedType().getTypeName();
    if (ON_NEW.equals(typeName)) {
      onNew = true;
    } else if (ON_UPDATE.equals(typeName)) {
      onUpdate = true;
    } else if (ON_DELETE.equals(typeName)) {
      onDelete = true;
    } else if (ALL.equals(typeName)) {
      onNew = true;
      onUpdate = true;
      onDelete = true;
    }
  }

  String getName() {
    return clazz.getName();
  }

  List<Entity> getObservedEntities() {
    if (observedEntities != null) {
      return observedEntities;
    }
    try {
      Constructor<?> c = clazz.getDeclaredConstructor();
      c.setAccessible(true);
      Method m = clazz.getDeclaredMethod("getObservedEntities");
      m.setAccessible(true);
      Entity[] entities = (Entity[]) m.invoke(c.newInstance());
      observedEntities = Arrays.asList(entities);
    } catch (Exception ex) {
      observedEntities = Collections.emptyList();
    }
    return observedEntities;
  }

  Set<String> getObservedEntityNames() {
    List<Entity> entities = getObservedEntities();
    if (observedEntities.isEmpty()) {
      return UNKNOWN;
    }
    return entities.stream().map(Entity::getName).collect(Collectors.toSet());
  }

  public boolean isOnNew() {
    return onNew;
  }

  public boolean isOnUpdate() {
    return onUpdate;
  }

  public boolean isOnDelete() {
    return onDelete;
  }

  @Override
  public boolean equals(Object o) {
    if (!(o instanceof EventHandler)) {
      return false;
    }
    return getName().equals(((EventHandler) o).getName());
  }

  @Override
  public int hashCode() {
    return getName().hashCode();
  }

}
