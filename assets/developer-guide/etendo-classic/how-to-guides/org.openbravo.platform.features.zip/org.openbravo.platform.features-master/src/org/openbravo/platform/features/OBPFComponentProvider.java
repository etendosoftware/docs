/************************************************************************************
 * Copyright (C) 2014-2020 Openbravo S.L.U.
 * Licensed under the Openbravo Commercial License version 1.0
 * You may obtain a copy of the License at http://www.openbravo.com/legal/obcl.html
 * or in the legal folder of this module distribution.
 ************************************************************************************/

package org.openbravo.platform.features;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.enterprise.context.ApplicationScoped;

import org.openbravo.client.kernel.BaseComponentProvider;
import org.openbravo.client.kernel.Component;
import org.openbravo.client.kernel.ComponentProvider;

/**
 * 
 * @author dbaz
 */
@ApplicationScoped
@ComponentProvider.Qualifier(OBPFComponentProvider.COMPONENT_TYPE)
public class OBPFComponentProvider extends BaseComponentProvider {
  public static final String COMPONENT_TYPE = "org.openbravo.platform.features_Resources";

  @Override
  public Component getComponent(String componentId, Map<String, Object> parameters) {
    throw new IllegalArgumentException("Component id " + componentId + " not supported.");
  }

  @Override
  public List<ComponentResource> getGlobalComponentResources() {
    final List<ComponentResource> globalResources = new ArrayList<>();

    globalResources.add(
        createStaticResource("web/org.openbravo.platform.features/js/OBPF_BPCreation.js", false));

    globalResources.add(createStaticResource(
        "web/org.openbravo.platform.features/js/OBPF_AddPayment_GridBtn.js", false));

    globalResources.add(
        createStaticResource("web/org.openbravo.platform.features/js/OBPF_showAlert.js", false));

    globalResources.add(
        createStaticResource("web/org.openbravo.platform.features/js/OBPF_BPOnChange.js", false));

    return globalResources;
  }
}
